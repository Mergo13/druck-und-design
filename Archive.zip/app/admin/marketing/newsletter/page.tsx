import { AdminShell } from "@/components/admin/admin-shell";
import { AdminModulePage } from "@/features/admin/modules/admin-module-page";
import { requireAdminPage } from "@/lib/admin-page-auth";

export default async function AdminNewsletterPage() {
  const { user } = await requireAdminPage();
  return <AdminShell title="Newsletter" email={user.email}><AdminModulePage moduleKey="newsletter" title="Newsletter" description="Newsletter-Kontakte und Abostatus." /></AdminShell>;
}
