import type { Metadata } from "next";
import { AdminShell } from "@/components/admin/admin-shell";
import { PageHeader } from "@/components/admin/page-header";
import { Badge } from "@/components/ui/badge";
import { requireAdminPage } from "@/lib/admin-page-auth";

export const metadata: Metadata = {
  title: "Admin",
  description: "Admin-Dashboard für Produkte, Neuigkeiten, Gruppen, Bestellungen, Rechnungen und Shop-Steuerung."
};

export default async function AdminPage() {
  const { user } = await requireAdminPage();
  return (
    <AdminShell title="Dashboard" email={user.email}>
      <PageHeader title="Dashboard" description="Betriebsübersicht für Verkauf, Katalog, Marketing und Shop-Steuerung." />
      <div className="grid gap-4 md:grid-cols-3">
        {[
          ["Verkauf", "Bestellungen, Angebote und Rechnungen sind in einem Verkaufsbereich gebündelt."],
          ["Katalog", "Produkte, Kategorien, Eigenschaften und Branchen liegen in einem gemeinsamen Katalogbereich."],
          ["Betrieb", "Uploads, Versand und tägliche Shop-Steuerung sind zusammengefasst."]
        ].map(([title, text]) => (
          <div key={title} className="rounded-lg border bg-white p-4">
            <Badge variant="outline">{title}</Badge>
            <p className="mt-3 text-sm font-medium text-slate-600">{text}</p>
          </div>
        ))}
      </div>
    </AdminShell>
  );
}
