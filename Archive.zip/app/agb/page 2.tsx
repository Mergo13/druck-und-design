export { default } from "./page";
