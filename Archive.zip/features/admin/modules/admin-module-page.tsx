"use client";

import { useEffect, useMemo, useState } from "react";
import { DataTable } from "@/components/admin/data-table/data-table";
import { DataTableColumnHeader } from "@/components/admin/data-table/data-table-column-header";
import { PageHeader } from "@/components/admin/page-header";
import { CsvExportMenu } from "@/components/admin/csv/csv-export-menu";
import type { ColumnDef } from "@tanstack/react-table";
import { Button } from "@/components/ui/button";
import { Edit } from "lucide-react";
import Link from "next/link";

type AdminRecord = Record<string, unknown> & { id?: string; status?: string; createdAt?: string; updatedAt?: string };

type AdminModulePageProps = {
  moduleKey: string;
  title: string;
  description: string;
  csvResource?: string;
  detailBasePath?: string;
};

export function AdminModulePage({ moduleKey, title, description, csvResource, detailBasePath }: AdminModulePageProps) {
  const [rows, setRows] = useState<AdminRecord[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError("");
      const response = await fetch(`/api/admin/modules/${moduleKey}?page=1&pageSize=100`);
      if (!response.ok) {
        setError(`${title} konnten nicht geladen werden.`);
      } else {
        const json = await response.json() as { items?: AdminRecord[] };
        setRows(json.items ?? []);
      }
      setLoading(false);
    }
    void load();
  }, [moduleKey, title]);

  const keys = useMemo(() => {
    const preferred = ["id", "customer", "email", "code", "name", "subject", "amount", "total", "status", "createdAt"];
    const available = new Set(rows.flatMap((row) => Object.keys(row)));
    return preferred.filter((key) => available.has(key)).slice(0, 6);
  }, [rows]);

  const columns = useMemo<ColumnDef<AdminRecord>[]>(() => [
    ...keys.map((key) => ({
      accessorKey: key,
      header: ({ column }) => <DataTableColumnHeader column={column} title={labelForKey(key)} />,
      cell: ({ row }) => formatValue(row.original[key])
    }) satisfies ColumnDef<AdminRecord>),
    ...(detailBasePath ? [{
      id: "actions",
      header: "",
      cell: ({ row }) => row.original.id ? (
        <Button asChild type="button" variant="ghost" size="sm">
          <Link href={`${detailBasePath}/${encodeURIComponent(String(row.original.id))}`}>
            <Edit className="h-4 w-4" />
            Öffnen
          </Link>
        </Button>
      ) : null
    } satisfies ColumnDef<AdminRecord>] : [])
  ], [detailBasePath, keys]);

  return (
    <>
      <PageHeader title={title} description={description} actions={csvResource ? <CsvExportMenu resource={csvResource} /> : null} />
      <DataTable
        columns={columns}
        data={rows}
        searchValue={query}
        onSearchChange={setQuery}
        searchPlaceholder={`${title} suchen...`}
        loading={loading}
        error={error}
      />
    </>
  );
}

function formatValue(value: unknown) {
  if (value === null || value === undefined) return "-";
  if (value instanceof Date) return value.toLocaleString("de-AT");
  if (typeof value === "number") return Number.isInteger(value) ? String(value) : value.toLocaleString("de-AT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (typeof value === "boolean") return value ? "yes" : "no";
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}/.test(value)) return new Date(value).toLocaleString("de-AT");
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function labelForKey(key: string) {
  const labels: Record<string, string> = {
    id: "ID",
    customer: "Kunde",
    email: "E-Mail",
    code: "Code",
    name: "Name",
    subject: "Betreff",
    amount: "Betrag",
    total: "Summe",
    status: "Status",
    createdAt: "Erstellt am",
    updatedAt: "Aktualisiert am"
  };
  return labels[key] ?? key;
}
