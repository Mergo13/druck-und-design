"use client";

import { ArrowLeft, Save } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/admin/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ProductCatalogItem, ProductCategory } from "@/types/print-platform";

type ProductEditPageProps = {
  slug: string;
};

function emptyProduct(): ProductCatalogItem {
  return {
    slug: "",
    name: "",
    category: "",
    visible: false,
    published: false,
    short: "",
    description: "",
    seo: "",
    heroImage: "",
    gallery: [],
    rating: 5,
    basePrice: 0,
    pricingType: "fixed",
    deliveryText: "",
    tags: [],
    variants: [],
    production: {
      baseProductionDays: 3,
      expressAvailable: false,
      preflightProfile: "standard-print",
      renderPipeline: "pdf-x4"
    },
    priceTiers: [{ quantity: 1, price: 0 }],
    pricingProperties: [],
    productStatus: "draft",
    industrySlugs: []
  };
}

export function ProductEditPage({ slug }: ProductEditPageProps) {
  const isNew = slug === "new";
  const [product, setProduct] = useState<ProductCatalogItem>(emptyProduct());
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [advancedJson, setAdvancedJson] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      setMessage("");
      const categoriesRes = await fetch("/api/catalog/categories?scope=admin");
      const nextCategories = categoriesRes.ok ? await categoriesRes.json() as ProductCategory[] : [];
      setCategories(nextCategories);
      if (isNew) {
        const next = { ...emptyProduct(), category: nextCategories[0]?.slug ?? "" };
        setProduct(next);
        setAdvancedJson(JSON.stringify(next, null, 2));
      } else {
        const productRes = await fetch(`/api/catalog/products/${encodeURIComponent(slug)}?scope=admin`);
        if (!productRes.ok) {
      setMessage("Produkt konnte nicht geladen werden.");
        } else {
          const nextProduct = await productRes.json() as ProductCatalogItem;
          setProduct(nextProduct);
          setAdvancedJson(JSON.stringify(nextProduct, null, 2));
        }
      }
      setLoading(false);
    }
    void load();
  }, [isNew, slug]);

  const status = useMemo(() => product.productStatus ?? (product.visible === false || product.published === false ? "inactive" : "active"), [product]);

  function update<K extends keyof ProductCatalogItem>(key: K, value: ProductCatalogItem[K]) {
    setProduct((current) => {
      const next = { ...current, [key]: value };
      setAdvancedJson(JSON.stringify(next, null, 2));
      return next;
    });
  }

  async function save() {
    setSaving(true);
    setMessage("");
    let payload = product;
    try {
      payload = JSON.parse(advancedJson) as ProductCatalogItem;
    } catch {
      setSaving(false);
      setMessage("Das erweiterte JSON ist ungültig.");
      return;
    }
    const response = await fetch("/api/catalog/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      const json = await response.json().catch(() => null) as { message?: string } | null;
      setMessage(json?.message ?? "Produkt konnte nicht gespeichert werden.");
      setSaving(false);
      return;
    }
    const saved = await response.json() as ProductCatalogItem;
    setProduct(saved);
    setAdvancedJson(JSON.stringify(saved, null, 2));
    setMessage("Gespeichert.");
    setSaving(false);
    if (isNew) window.history.replaceState(null, "", `/admin/catalog/products/${encodeURIComponent(saved.slug)}`);
  }

  return (
    <>
      <PageHeader
        title={isNew ? "Neues Produkt" : `Produkt: ${product.name || slug}`}
        description="Produktdaten bearbeiten, ohne Preis-, Konfigurator-, Produktions- oder Lieferkonfiguration zu vereinfachen."
        actions={
          <>
            <Button asChild variant="outline" size="sm">
              <Link href="/admin/catalog/products">
                <ArrowLeft className="h-4 w-4" />
                Produkte
              </Link>
            </Button>
            <Button type="button" size="sm" onClick={save} disabled={saving || loading}>
              <Save className="h-4 w-4" />
              {saving ? "Speichert..." : "Speichern"}
            </Button>
          </>
        }
      />

      {message ? <div className="mb-4 rounded-md border bg-white p-3 text-sm font-semibold text-slate-700">{message}</div> : null}

      <Tabs defaultValue="general" className="min-w-0">
        <TabsList className="flex h-auto flex-wrap justify-start">
          <TabsTrigger value="general">Allgemein</TabsTrigger>
          <TabsTrigger value="pricing">Preise</TabsTrigger>
          <TabsTrigger value="options">Optionen</TabsTrigger>
          <TabsTrigger value="production">Produktion</TabsTrigger>
          <TabsTrigger value="delivery">Lieferung</TabsTrigger>
          <TabsTrigger value="media">Medien</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="advanced">Erweitert</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Panel>
            <Field label="Name"><Input value={product.name} onChange={(event) => update("name", event.target.value)} /></Field>
            <Field label="Slug"><Input value={product.slug} onChange={(event) => update("slug", event.target.value)} disabled={!isNew} /></Field>
            <Field label="Kategorie">
              <Select value={product.category} onValueChange={(value) => update("category", value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{categories.map((category) => <SelectItem key={category.slug} value={category.slug}>{category.name}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={status} onValueChange={(value) => update("productStatus", value as ProductCatalogItem["productStatus"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Entwurf</SelectItem>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="inactive">Inaktiv</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <div className="sm:col-span-2"><Field label="Kurzbeschreibung"><Input value={product.short} onChange={(event) => update("short", event.target.value)} /></Field></div>
            <div className="sm:col-span-2"><TextAreaField label="Beschreibung" value={product.description} onChange={(value) => update("description", value)} /></div>
          </Panel>
        </TabsContent>

        <TabsContent value="pricing">
          <Panel>
            <Field label="Basispreis"><Input type="number" step="0.01" value={product.basePrice} onChange={(event) => update("basePrice", Number(event.target.value))} /></Field>
            <Field label="Preisart">
              <Select value={product.pricingType ?? "fixed"} onValueChange={(value) => update("pricingType", value as ProductCatalogItem["pricingType"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixed">Fixpreis</SelectItem>
                  <SelectItem value="tiered">Staffelpreis</SelectItem>
                  <SelectItem value="area">Fläche</SelectItem>
                  <SelectItem value="hourly">Stundensatz</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Summary label="Mengenstaffeln" value={product.priceTiers?.length ?? 0} />
            <Summary label="Preis-Eigenschaften" value={product.pricingProperties?.length ?? 0} />
            <div className="sm:col-span-2 text-sm text-slate-500">Detaillierte Preiskomponenten und Schutzregeln bleiben im erweiterten JSON erhalten, bis eigene shadcn-Editoren migriert sind.</div>
          </Panel>
        </TabsContent>

        <TabsContent value="options">
          <Panel>
            <Summary label="Konfiguratorprofil" value={typeof product.configuratorProfile === "string" ? product.configuratorProfile : "standard"} />
            <Summary label="Darstellungsprofil" value={product.experienceProfile ?? "standard"} />
            <Summary label="Varianten" value={product.variants?.length ?? 0} />
            <Summary label="Zugeordnete Branchen" value={product.industrySlugs?.length ?? 0} />
          </Panel>
        </TabsContent>

        <TabsContent value="production">
          <Panel>
            <Summary label="PDF-Analyse" value={product.pdfAnalysisMode ?? "disabled"} />
            <Summary label="Bindungskonfiguration" value={product.productBindingConfig ? "konfiguriert" : "nicht konfiguriert"} />
            <Summary label="Produktionstage" value={product.production?.baseProductionDays ?? "-"} />
            <Summary label="Render-Pipeline" value={product.production?.renderPipeline ?? "-"} />
          </Panel>
        </TabsContent>

        <TabsContent value="delivery">
          <Panel>
            <div className="sm:col-span-2"><TextAreaField label="Liefertext" value={product.deliveryText} onChange={(value) => update("deliveryText", value)} /></div>
          </Panel>
        </TabsContent>

        <TabsContent value="media">
          <Panel>
            <Field label="Hero-Bild"><Input value={product.heroImage} onChange={(event) => update("heroImage", event.target.value)} /></Field>
            <Summary label="Galeriebilder" value={product.gallery?.length ?? 0} />
          </Panel>
        </TabsContent>

        <TabsContent value="seo">
          <Panel>
            <div className="sm:col-span-2"><TextAreaField label="SEO" value={product.seo} onChange={(value) => update("seo", value)} /></div>
            <Summary label="Tags" value={product.tags?.join(", ") || "-"} />
          </Panel>
        </TabsContent>

        <TabsContent value="advanced">
          <div className="rounded-lg border bg-white p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-black text-slate-950">Vollständiges Produkt-JSON</p>
                <p className="text-sm text-slate-500">Erhält komplexe Preis-, Options-, Liefer-, Produktions- und Konfigurator-Daten.</p>
              </div>
              <Badge variant="outline">slug keyed</Badge>
            </div>
            <textarea
              value={advancedJson}
              onChange={(event) => setAdvancedJson(event.target.value)}
              className="min-h-[560px] w-full rounded-md border bg-slate-950 p-4 font-mono text-xs text-slate-50 outline-none focus:ring-2 focus:ring-ring"
              spellCheck={false}
            />
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
}

function Panel({ children }: { children: React.ReactNode }) {
  return <div className="grid gap-4 rounded-lg border bg-white p-4 sm:grid-cols-2">{children}</div>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs font-black uppercase text-slate-500">{label}</span>
      {children}
    </label>
  );
}

function TextAreaField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs font-black uppercase text-slate-500">{label}</span>
      <textarea value={value} onChange={(event) => onChange(event.target.value)} className="min-h-36 rounded-md border bg-white p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
    </label>
  );
}

function Summary({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-md border bg-slate-50 p-3">
      <p className="text-xs font-black uppercase text-slate-500">{label}</p>
      <p className="mt-1 text-sm font-bold text-slate-950">{value}</p>
    </div>
  );
}
