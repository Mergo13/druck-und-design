
# Druck & Design Premium Platform

Premium Next.js ecommerce + werbetechnik platform starter architecture.

## Stack
- Next.js 15
- TypeScript
- TailwindCSS
- Stripe
- Prisma
- PostgreSQL
- Framer Motion
- Zustand

## Features
- Login-only pricing
- Staffelpreise
- Production speed pricing
- Admin dashboard
- Product configurator
- Stripe checkout
- GDPR-ready structure
- Marketing integrations

## Install

```bash
npm install
npm run dev
```

## Production

```bash
npm run build
npm start
```
