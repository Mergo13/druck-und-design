
export default function AdminDashboard() {
  return (
    <main className="min-h-screen bg-zinc-950 text-white p-10">
      <h1 className="text-4xl font-bold mb-10">Admin Dashboard</h1>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-zinc-900 rounded-2xl p-6">
          <h2 className="text-xl">Orders</h2>
          <p className="text-4xl mt-4">128</p>
        </div>

        <div className="bg-zinc-900 rounded-2xl p-6">
          <h2 className="text-xl">Revenue</h2>
          <p className="text-4xl mt-4">€24,820</p>
        </div>

        <div className="bg-zinc-900 rounded-2xl p-6">
          <h2 className="text-xl">Customers</h2>
          <p className="text-4xl mt-4">481</p>
        </div>
      </div>
    </main>
  )
}
