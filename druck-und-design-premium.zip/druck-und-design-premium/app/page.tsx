
export default function HomePage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <section className="h-screen flex flex-col items-center justify-center">
        <h1 className="text-7xl font-bold tracking-tight">
          DRUCK & DESIGN
        </h1>

        <p className="mt-6 text-zinc-400 max-w-xl text-center">
          Premium Werbetechnik, Fahrzeugfolierung und kreative Produktion.
        </p>

        <button className="mt-10 rounded-full bg-white text-black px-8 py-4">
          Produkte entdecken
        </button>
      </section>
    </main>
  )
}
