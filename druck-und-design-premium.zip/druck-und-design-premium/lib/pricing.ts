
export const productionPricing = {
  express: 1.25,
  fast: 1.15,
  standard: 1,
  economy: 0.9,
  budget: 0.8,
}

export function calculatePrice(base: number, multiplier: number) {
  return base * multiplier
}
